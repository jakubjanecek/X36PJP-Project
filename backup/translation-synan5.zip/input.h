int initializeInput( char * );
int readChar();
void closeInput();
