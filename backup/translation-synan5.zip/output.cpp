/*
 * output.cpp - Jakub Janecek, janecj3@fel.cvut.cz
 * This module takes care of output to a file. It opens a file, writes to it by lines and then closes it.
 */

#include <iostream>
#include <fstream>
using namespace std;

ofstream outFile;

/*
 * Initializes the output.
 * Returns 0 when successful and -1 when unsuccessful.
 */
int initializeOutput(char * filename ) {
  outFile.open( filename, ifstream::out );
  if ( outFile.is_open() ) {
    return( 0 );
  }
  else {
    return( -1 );
  }
}

/*
 * Writes a line into output.
 * Returns 0 when successful and -1 when unsuccessful.
 */
int write( char * buffer ) {
  if ( outFile.good() ) {
    outFile << buffer << endl;
  }
  else {
    return ( -1 );
  }
  return( 0 );
}

/*
 * Closes the input. It needs to be called after all work has been done.
 */
void closeOutput() {
  if ( outFile.is_open() ) {
    outFile.close();
  }
  return;
}
