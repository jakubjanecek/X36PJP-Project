int initializeOutput( char * );
int write( char * );
void closeOutput();
