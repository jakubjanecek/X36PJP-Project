#include "symboltable.h"
#include "synan.h"
#include "lexan.h"
#include "output.h"
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

void Program();
void Blok();
void UsekDeklaraciPromennych();
void DeklaracePromennych();
void SeznamIdentifikatoru();
void ZbytekSeznamuIdentifikatoru();
void OznaceniTypu();
void ZbytekDeklaraciPromennych();
void SlozenyPrikaz();
void PosloupnostPrikazu();
void Prikaz();
void PrazdnyPrikaz();
void PrirazovaciPrikaz();
bool Vyraz();
bool Znamenko();
bool Term();
bool Faktor();
bool ZbytekTermu( bool left );
char * MultiplikativniOperator();
bool ZbytekVyrazu( bool left );
char * AditivniOperator();
void ZbytekPosloupnostiPrikazu();
int PrikazIf( int first );
void Podminka( int label );
int RelacniOperator();
int CastElse( int first );
void PrikazWhile();
void PrikazFor();
void CastFor();
void PrikazWriteln();

int labels = 0;

void synError( string msg ) {
  cout << endl << "SYNAN ERROR: " << msg << endl << endl;
  exit( -1 );
}

void initializeSynan( char * filename ) {
  if ( initializeOutput( filename ) == -1 ) {
    synError( "Output couldn't be opened." );
  }
  Program();
  return;
}

void cleanUpSynan() {
  closeOutput();
  return;
}

void compare( LexSymbol s ) {
  if ( symb == s ) {
    readSymb();
  }
  else {
    synError( "Comparison error at compare()." );
  }
}

void compareIdent( char * id ) {
  if ( symb == IDENT ) {
    strcpy( id, ident );
    readSymb();
  }
  else {
    synError( "Comparison error at compareIdent()." );
  }
}

int compareInt() {
  if ( symb == INT ) {
     int value = number;
     readSymb();
     return value;
  }
  else {
    synError( "Comparison error at compareInt()." );
  }
}

double compareFloat() {
  if ( symb == FLOAT ) {
     double value = realNumber;
     readSymb();
     return value;
  }
  else {
    synError( "Comparison error at compareFloat()." );
  }
}

void instruction( char *instr ) {
  write( instr );
}

void binOp( char *instr, bool left, bool right ) {
  char string[128];
  if ( left ) {
    if ( right ) {
      sprintf( string, "d%s", instr );
      write( string );
    }
    else {
      sprintf( string, "i2d\nd%s", instr );
      write( string );
    }
  }
  else {
    if ( right ) {
      synError( "Can't convert left operand at binOp()." );
    }
    else {
      sprintf( string, "i%s", instr );
      write( string );
    }
  }
}

void Program() {
  char programName[32];
  char instr[128];
  cout << "1 Program -> program identifikator ; Blok ." << endl;
  compare( kwPROGRAM );
  compareIdent( programName );
  compare( SCOL );
  sprintf( instr, ".class public %s", programName );
  instruction( instr );
  instruction( ".super java/lang/Object" );
  instruction( ".method public static main([Ljava/lang/String;)V" );
  instruction( ".limit stack 100" );
  instruction( ".limit locals 100" );
  Blok();
  compare( DOT );
  instruction( "return" );
  instruction( ".end method" );
}

void Blok() {
  switch ( symb ) {
    case kwVAR: case kwBEGIN:
      cout << "2 Blok -> UsekDeklaraciPromennych SlozenyPrikaz" << endl;
      UsekDeklaraciPromennych();
      SlozenyPrikaz();   
      break;
    default:
      synError( "At Blok." );
  }
}

void UsekDeklaraciPromennych() {
  switch ( symb ) {
    case kwVAR:
      cout << "3 UsekDeklaraciPromennych -> var DeklaracePromennych ; ZbytekDeklaraciPromennych" << endl;
      readSymb();
      DeklaracePromennych();
      compare( SCOL );
      ZbytekDeklaraciPromennych();
      break;
    default:
      cout << "4 UsekDeklaraciPromennych -> e" << endl;
  }
}

void DeklaracePromennych() {
  cout << "5 DeklaracePromennych -> SeznamIdentifikatoru : OznaceniTypu" << endl;
  SeznamIdentifikatoru();
  compare( COL );
  OznaceniTypu();
}

void SeznamIdentifikatoru() {
  cout << "6 SeznamIdentifikatoru -> identifikator ZbytekSeznamuIdentifikatoru" << endl;
  char i[32];
  compareIdent( i );
  addVariable( i );
  ZbytekSeznamuIdentifikatoru();
}

void ZbytekSeznamuIdentifikatoru() {
  switch ( symb ) {
    case COM:
      cout << "7 ZbytekSeznamuIdentifikatoru -> , SeznamIdentifikatoru" << endl;
      readSymb();
      SeznamIdentifikatoru();
      break;
    default:
      cout << "8 ZbytekSeznamuIdentifikatoru -> e" << endl;
  }
}

void OznaceniTypu() {
  switch ( symb ) {
    case kwINTEGER:
      cout << "9 OznaceniTypu -> integer" << endl;
      changeType( INTNUM );
      readSymb();
      break;
    case kwREAL:
      cout << "10 OznaceniTypu -> real" << endl;
      changeType( REALNUM );
      readSymb();
      break;
    default:
      synError( "At OznaceniTypu." );
  }
}

void ZbytekDeklaraciPromennych() {
  switch ( symb ) {
    case IDENT:
      cout << "11 ZbytekDeklaraciPromennych -> DeklaracePromennych ; ZbytekDeklaraciPromennych" << endl;
      DeklaracePromennych();
      compare( SCOL );
      ZbytekDeklaraciPromennych();
      break;
    default:
      cout << "12 ZbytekDeklaraciPromennych -> e" << endl;
  }
}

void SlozenyPrikaz() {
  cout << "13 SlozenyPrikaz -> begin PosloupnostPrikazu end" << endl;
  compare( kwBEGIN );
  PosloupnostPrikazu();
  compare( kwEND );
}

void PosloupnostPrikazu() {
  switch ( symb ) {
    case IDENT: case kwBEGIN: case kwIF: case kwWHILE: case kwWRITELN: case SCOL: case kwEND:
      cout << "14 PosloupnostPrikazu -> Prikaz ZbytekPosloupnostiPrikazu" << endl;   
      Prikaz();
      ZbytekPosloupnostiPrikazu();
      break;
    default:
      synError( "At PosloupnostPrikazu." );
  }
}

void Prikaz() {
  switch ( symb ) {
    case IDENT:
      cout << "15 Prikaz -> PrirazovaciPrikaz" << endl;
      PrirazovaciPrikaz();
      break;
    case kwBEGIN:
      cout << "16 Prikaz -> SlozenyPrikaz" << endl;
      SlozenyPrikaz();
      break;
    case kwIF:
      cout << "17 Prikaz -> PrikazIf" << endl;
      labels = PrikazIf( labels );
      break;
    case kwWHILE:
      cout << "18 Prikaz -> PrikazWhile" << endl;
      PrikazWhile();
      break;
    case kwFOR:
      cout << "19 Prikaz -> PrikazFor" << endl;
      PrikazFor();
      break;
    case kwWRITELN:
      cout << "20 Prikaz -> PrikazWriteln" << endl;
      PrikazWriteln();
      break;
    case SCOL: case kwELSE: case kwEND:
      cout << "21 Prikaz -> PrazdnyPrikaz" << endl;
      PrazdnyPrikaz();
      break;
    default:
      synError( "At Prikaz." );
  }
}

void PrazdnyPrikaz() {
  cout << "22 PrazdnyPrikaz -> e" << endl;
}

void PrirazovaciPrikaz() {
  cout << "23 PrirazovaciPrikaz -> identifikator := Vyraz" << endl;
  char instr[128];
  char i[32];
  Item * p;
  bool type;
  compareIdent( i );
  p = find( i );
  compare( ASSIGN );
  type = Vyraz();
  if ( p != NULL ) {
    if ( ( p -> type == INTNUM && !type ) || ( p -> type == REALNUM && type ) ) {
      if ( type ) {
        sprintf( instr, "dstore %d", p -> address );
        instruction( instr );
      }
      else {
        sprintf( instr, "istore %d", p -> address );
        instruction( instr );
      }
    }
    else {
      synError( "Different variable type." );
    }
  }
  else { 
    synError( "Variable not declared." );
  }
}

bool Vyraz() {
  bool tempType;
  bool tempType1;
  switch ( symb ) {
    case PLUS: case MINUS: case IDENT: case INT: case FLOAT: case LPAR:
      cout << "24 Vyraz -> Znamenko Term ZbytekVyrazu" << endl;
      tempType = Znamenko();
      tempType1 = Term();
      if ( !tempType ) {
        if ( tempType1 ) {
          instruction( "dneg" );
        }
        else {
          instruction( "ineg" );
        }
      }
      return ZbytekVyrazu( tempType1 );
      break;
    default:
      synError( "At Vyraz." );
  }
}

bool Znamenko() {
  switch ( symb ) {
    case PLUS:
      cout << "25 Znamenko -> +" << endl;
      readSymb();
      return true; // positive
      break;
    case MINUS:
      cout << "26 Znamenko -> -" << endl;
      readSymb();
      return false; // negative
      break;
    default:
      cout << "27 Znamenko -> e" << endl;
      return true; // positive
  }
}

bool Term() {
  bool tempType;
  switch ( symb ) {
    case IDENT: case INT: case FLOAT: case LPAR:
      cout << "28 Term -> Faktor ZbytekTermu" << endl;
      tempType = Faktor();
      return ZbytekTermu( tempType );
      break;
    default:
      synError( "At Term." );
  }
}

bool Faktor() {
  bool tempType;
  char * number;
  char instr[128];
  Item * p;
  switch ( symb ) {
    case IDENT:
      cout << "29 Faktor -> identifikator" << endl;
      p = find( ident );
      if ( p != NULL ) {
        if ( p -> type == INTNUM ) {
          sprintf( instr, "iload %d", p -> address );
          instruction( instr );
          readSymb();
          return false;
        }
        else {
          sprintf( instr, "dload %d", p -> address );
          instruction( instr );
          readSymb();
          return true;
        }
      }
      else {
        synError( "Variable not declared." );
      }
      break;
    case INT:
      cout << "30 Faktor -> celeCislo" << endl;
      sprintf( instr, "ldc %d", compareInt() );
      instruction( instr );
      //readSymb();
      return false;
      break;
    case FLOAT:
      cout << "31 Faktor -> realneCislo" << endl;
      sprintf( instr, "ldc2_w %f", compareFloat() );
      instruction( instr );
      //readSymb();
      return true;
      break;
    case LPAR:
      cout << "32 Faktor -> ( Vyraz )" << endl;
      readSymb();
      tempType = Vyraz();
      compare( RPAR );
      return tempType;
      break;
    default:
      synError( "At Faktor." );
  }
}

bool ZbytekTermu( bool left ) {
  char * operation;
  bool right;
  bool tempType;
  switch ( symb ) {
    case ASTER: case SLASH: case kwDIV: case kwMOD:
      cout << "33 ZbytekTermu -> MultiplikativniOperator Faktor ZbytekTermu" << endl;
      operation = MultiplikativniOperator();
      right = Faktor();
      binOp( operation, left, right );
      tempType = ZbytekTermu( left || right );
      return tempType;
      break;
    case PLUS: case MINUS: case EQ: case NEQ: case LESS: case GREAT: case LESSEQ: case GREATEQ: case SCOL: case RPAR: case kwDO: case kwIF:
    case kwTHEN: case kwELSE: case kwTO: case kwDOWNTO: case kwWRITELN: case kwFOR: case IDENT:
      cout << "34 ZbytekTermu -> e" << endl;
      return left;
      break;
    default:
      synError( "At ZbytekTermu." );
  }
}

char * MultiplikativniOperator() {
  switch ( symb ) {
    case ASTER:
      cout << "35 MultiplikativniOperator -> *" << endl;
      readSymb();
      return "mul";
      break;
    case SLASH:
      cout << "36 MultiplikativniOperator -> /" << endl;
      readSymb();
      return "div";
      break;
    case kwDIV:
      cout << "37 MultiplikativniOperator -> div" << endl;
      readSymb();
      return "div";
      break;
    case kwMOD:
      cout << "38 MultiplikativniOperator -> mod" << endl;
      readSymb();
      return "rem";
      break;
    default:
      synError( "At MultiplikativniOperator." );
  }
}

bool ZbytekVyrazu( bool left ) {
  char * operation;
  bool right;
  switch ( symb ) {
    case PLUS: case MINUS:
      cout << "39 ZbytekVyrazu -> AditivniOperator Term ZbytekVyrazu" << endl;
      operation = AditivniOperator();
      right = Term();
      binOp( operation, left, right );
      return ZbytekVyrazu( left || right );
      break;
    default:
      cout << "40 ZbytekVyrazu -> e" << endl;
      return left;
  }
}

char * AditivniOperator() {
  switch ( symb ) {
    case PLUS:
      cout << "41 AditivniOperator -> +" << endl;
      readSymb();
      return "add";
      break;
    case MINUS:
      cout << "42 AditivniOperator -> -" << endl;
      readSymb();
      return "sub";
      break;
    default:
      synError( "At AditivniOperator." );
  }
}

void ZbytekPosloupnostiPrikazu() {
  switch ( symb ) {
    case SCOL:
      cout << "43 ZbytekPosloupnostiPrikazu -> ; Prikaz ZbytekPosloupnostiPrikazu" << endl;
      readSymb();
      Prikaz();
      ZbytekPosloupnostiPrikazu();
      break;
    default:
      cout << "44 ZbytekPosloupnostiPrikazu -> e" << endl;
  }
}

int PrikazIf( int first ) {
  cout << "45 PrikazIf -> if Podminka then Prikaz CastElse" << endl;
  compare( kwIF );
  Podminka( first );
  compare( kwTHEN );
  Prikaz();
  return CastElse( first + 1 );
}

void Podminka( int label ) {
  bool left;
  bool right;
  int operation;
  char instr[128];
  switch ( symb ) {
    case PLUS: case MINUS: case IDENT: case INT: case FLOAT: case LPAR:
      cout << "46 Podminka -> Vyraz RelacniOperator Vyraz" << endl;
      left = Vyraz();
      operation = RelacniOperator();
      right = Vyraz();
      if ( !left && right ) {
        synError( "Can't convert left operand at Podminka()." );
      }
      if ( !left && !right ) {
         switch ( operation ) {
           case 0:
             sprintf( instr, "if_icmpne Label%d", label );
             instruction( instr );
             break;
           case 1:
             sprintf( instr, "if_icmpeq Label%d", label );
             instruction( instr );
             break;
           case 2:
             sprintf( instr, "if_icmpgt Label%d", label );
             instruction( instr );
             break;
           case 3:
             sprintf( instr, "if_icmplt Label%d", label );
             instruction( instr );
             break;
           case 4:
             sprintf( instr, "if_icmpge Label%d", label );
             instruction( instr );
             break;
           case 5:
             sprintf( instr, "if_icmple Label%d", label );
             instruction( instr );
             break;
           default:
             synError( "Unexpected state at Podminka()." );
         } 
      }
      if ( left && right ) {
         switch ( operation ) {
           case 0:
             instruction( "dcmpg" );
             sprintf( instr, "ifne Label%d", label );
             instruction( instr );
             break;
           case 1:
             instruction( "dcmpg" );
             sprintf( instr, "ifeq Label%d", label );
             instruction( instr );
             break;
           case 2:
             instruction( "dcmpg" );
             sprintf( instr, "ifgt Label%d", label );
             instruction( instr );
             break;
           case 3:
             sprintf( instr, "iflt Label%d", label );
             instruction( instr );
             break;
           case 4:
             instruction( "dcmpg" );
             sprintf( instr, "ifge Label%d", label );
             instruction( instr );
             break;
           case 5:
             instruction( "dcmpg" );
             sprintf( instr, "ifle Label%d", label );
             instruction( instr );
             break;
           default:
             synError( "Unexpected state at Podminka()." );
         } 
      }
      if ( left && !right ) {
         switch ( operation ) {
           case 0:
             instruction( "i2d" );
             instruction( "dcmpg" );
             sprintf( instr, "ifne Label%d", label );
             instruction( instr );
             break;
           case 1:
             instruction( "i2d" );
             instruction( "dcmpg" );
             sprintf( instr, "ifeq Label%d", label );
             instruction( instr );
             break;
           case 2:
             instruction( "i2d" );
             instruction( "dcmpg" );
             sprintf( instr, "ifgt Label%d", label );
             instruction( instr );
             break;
           case 3:
             instruction( "i2d" );
             sprintf( instr, "iflt Label%d", label );
             instruction( instr );
             break;
           case 4:
             instruction( "i2d" );
             instruction( "dmpcg" );
             sprintf( instr, "ifge Label%d", label );
             instruction( instr );
             break;
           case 5:
             instruction( "i2d" );
             instruction( "dcmpg" );
             sprintf( instr, "ifle Label%d", label );
             instruction( instr );
             break;
           default:
             synError( "Unexpected state at Podminka()." );
         } 
      }
      break;
    default:
      synError( "At Podminka." );
  }
}

int RelacniOperator() {
  switch ( symb ) {
    case EQ:
      cout << "47 RelacniOperator -> =" << endl;
      readSymb();
      return 0;
      break;
    case NEQ:
      cout << "48 RelacniOperator -> <>" << endl;
      readSymb();
      return 1;
      break;
    case LESS:
      cout << "49 RelacniOperator -> <" << endl;
      readSymb();
      return 2;
      break;
    case GREAT:
      cout << "50 RelacniOperator -> >" << endl;
      readSymb();
      return 3;
      break;
    case LESSEQ:
      cout << "51 RelacniOperator -> <=" << endl;
      readSymb();
      return 4;
      break;
    case GREATEQ:
      cout << "52 RelacniOperator -> >=" << endl;
      readSymb();
      return 5;
      break;
    default:
      synError( "At RelacniOperator." );
  }
}

int CastElse( int first ) {
  char instr[128];
  switch ( symb ) {
    case kwELSE:
      cout << "53 CastElse -> else Prikaz" << endl;
      readSymb();
      sprintf( instr, "goto Label%d", first );
      instruction( instr );
      sprintf( instr, "Label%d:", first - 1 );
      instruction( instr );
      Prikaz();
      sprintf( instr, "Label%d:", first );
      instruction( instr );
      return ( first + 1 );
      break;
    default:
      cout << "54 CastElse -> e" << endl;
      sprintf( instr, "Label%d:", first - 1 );
      instruction( instr );
      return first;
  }
}

void PrikazWhile() {
  cout << "55 PrikazWhile -> while Podminka do Prikaz" << endl;
  compare( kwWHILE );
  Podminka( 0 ); // 0 doplnena pro funkcnost!!!
  compare( kwDO );
  Prikaz();
}

void PrikazFor() {
  cout << "56 PrikazFor -> for identifikator := Vyraz CastFor Vyraz do Prikaz" << endl;
  compare( kwFOR );
  compare( IDENT );
  compare( ASSIGN );
  Vyraz();
  CastFor();
  Vyraz();
  compare( kwDO );
  Prikaz();
}

void CastFor() {
  switch ( symb ) {
    case kwTO:
      cout << "57 CastFor -> to" << endl;
      readSymb();
      break;
    case kwDOWNTO:
      cout << "58 CastFor -> downto" << endl;
      readSymb();
      break;
    default:
      synError( "At CastFor." );
  }
}

void PrikazWriteln() {
  bool tempType;
  char cmd[128];
  cout << "59 PrikazWriteln -> writeln ( Vyraz )" << endl;
  compare( kwWRITELN );
  instruction( "getstatic java/lang/System/out Ljava/io/PrintStream;" );
  compare( LPAR );
  tempType = Vyraz();
  compare( RPAR );
  char ch = ( tempType == true ) ? 'D' : 'I';
  sprintf( cmd, "invokevirtual java/io/PrintStream/println(%c)V", ch);
  instruction( cmd );
}
