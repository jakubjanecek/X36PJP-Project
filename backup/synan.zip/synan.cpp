#include "synan.h"
#include "lexan.h"
#include <iostream>
using namespace std;

void Blok();
void UsekDeklaraciPromennych();
void DeklaracePromennych();
void SeznamIdentifikatoru();
void ZbytekSeznamuIdentifikatoru();
void OznaceniTypu();
void ZbytekDeklaraciPromennych();
void SlozenyPrikaz();
void PosloupnostPrikazu();
void Prikaz();
void PrazdnyPrikaz();
void PrirazovaciPrikaz();
void Vyraz();
void Znamenko();
void Term();
void Faktor();
void ZbytekTermu();
void MultiplikativniOperator();
void ZbytekVyrazu();
void AditivniOperator();
void ZbytekPosloupnostiPrikazu();
void PrikazIf();
void Podminka();
void RelacniOperator();
void CastElse();
void PrikazWhile();
void PrikazFor();
void CastFor();
void PrikazWriteln();

void synError( string msg ) {
  cout << endl << "SYNAN ERROR: " << msg << endl << endl;
  exit( -1 );
}

void compare( LexSymbol s ) {
  if ( s == symb ) {
    readSymb();
  }
  else {
    synError( "Comparison error." );
  }
}

void Program() {
  switch ( symb ) {
    case kwPROGRAM:
      cout << "1 Program -> program identifikator ; Blok ." << endl;
      compare( kwPROGRAM );
      compare( IDENT );
      compare( SCOL );
      Blok();
      compare( DOT );
      break;       
    default:
      synError( "Code must start with keyword PROGRAM." );
  }
}

void Blok() {
  switch ( symb ) {
    case kwVAR: case kwBEGIN:
      cout << "2 Blok -> UsekDeklaraciPromennych SlozenyPrikaz" << endl;
      UsekDeklaraciPromennych();
      SlozenyPrikaz();   
      break;
    default:
      synError( "At Blok." );
  }
}

void UsekDeklaraciPromennych() {
  switch ( symb ) {
    case kwVAR:
      cout << "3 UsekDeklaraciPromennych -> var DeklaracePromennych ; ZbytekDeklaraciPromennych" << endl;
      compare( kwVAR );
      DeklaracePromennych();
      compare( SCOL );
      ZbytekDeklaraciPromennych();
      break;
    case kwBEGIN:
      cout << "4 UsekDeklaraciPromennych -> e" << endl;
      break;
    default:
      synError( "At UsekDeklaraciPromennych." );
  }
}

void DeklaracePromennych() {
  switch ( symb ) {
    case IDENT:
      cout << "5 DeklaracePromennych -> SeznamIdentifikatoru : OznaceniTypu" << endl;
      SeznamIdentifikatoru();
      compare( COL );
      OznaceniTypu();
      break;
    default:
      synError( "At DeklaracePromennych." );
  }
}

void SeznamIdentifikatoru() {
  switch ( symb ) {
    case IDENT:
      cout << "6 SeznamIdentifikatoru -> identifikator ZbytekSeznamuIdentifikatoru" << endl;
      compare( IDENT );
      ZbytekSeznamuIdentifikatoru();
      break;
    default:
      synError( "At SeznamIdentifikatoru." );
  }
}

void ZbytekSeznamuIdentifikatoru() {
  switch ( symb ) {
    case COM:
      cout << "7 ZbytekSeznamuIdentifikatoru -> , SeznamIdentifikatoru" << endl;
      compare( COM );
      SeznamIdentifikatoru();
      break;
    case COL:
      cout << "8 ZbytekSeznamuIdentifikatoru -> e" << endl;
      break;
    default:
      synError( "At ZbytekSeznamuIdentifikatoru." );
  }
}

void OznaceniTypu() {
  switch ( symb ) {
    case kwINTEGER:
      cout << "9 OznaceniTypu -> integer" << endl;
      compare( kwINTEGER );
      break;
    case kwREAL:
      cout << "10 OznaceniTypu -> real" << endl;
      compare( kwREAL );
      break;
    default:
      synError( "At OznaceniTypu." );
  }
}

void ZbytekDeklaraciPromennych() {
  switch ( symb ) {
    case IDENT:
      cout << "11 ZbytekDeklaraciPromennych -> DeklaracePromennych ; ZbytekDeklaraciPromennych" << endl;
      DeklaracePromennych();
      compare( SCOL );
      ZbytekDeklaraciPromennych();
      break;
    case kwBEGIN:
      cout << "12 ZbytekDeklaraciPromennych -> e" << endl;
      break;
    default:
      synError( "At ZbytekDeklaraciPromennych." );
  }
}

void SlozenyPrikaz() {
  switch ( symb ) {
    case kwBEGIN:
      cout << "13 SlozenyPrikaz -> begin PosloupnostPrikazu end" << endl;
      compare( kwBEGIN );
      PosloupnostPrikazu();
      compare( kwEND );
      break;
    default:
      synError( "At SlozenyPrikaz." );
  }
}

void PosloupnostPrikazu() {
  switch ( symb ) {
    case IDENT: case kwBEGIN: case kwIF: case kwWHILE: case kwWRITELN: case SCOL: case kwEND:
      cout << "14 PosloupnostPrikazu -> Prikaz ZbytekPosloupnostiPrikazu" << endl;   
      Prikaz();
      ZbytekPosloupnostiPrikazu();
      break;
    default:
      synError( "At PosloupnostPrikazu." );
  }
}

void Prikaz() {
  switch ( symb ) {
    case IDENT:
      cout << "15 Prikaz -> PrirazovaciPrikaz" << endl;
      PrirazovaciPrikaz();
      break;
    case kwBEGIN:
      cout << "16 Prikaz -> SlozenyPrikaz" << endl;
      SlozenyPrikaz();
      break;
    case kwIF:
      cout << "17 Prikaz -> PrikazIf" << endl;
      PrikazIf();
      break;
    case kwWHILE:
      cout << "18 Prikaz -> PrikazWhile" << endl;
      PrikazWhile();
      break;
    case kwFOR:
      cout << "19 Prikaz -> PrikazFor" << endl;
      PrikazFor();
      break;
    case kwWRITELN:
      cout << "20 Prikaz -> PrikazWriteln" << endl;
      PrikazWriteln();
      break;
    case SCOL: case kwELSE: case kwEND:
      cout << "21 Prikaz -> PrazdnyPrikaz" << endl;
      PrazdnyPrikaz();
      break;
    default:
      synError( "At Prikaz." );
  }
}

void PrazdnyPrikaz() {
  switch ( symb ) {
    case SCOL: case kwELSE: case kwEND:
      cout << "22 PrazdnyPrikaz -> e" << endl;
      break;
    default:
      synError( "At PrazdnyPrikaz." );
  }
}

void PrirazovaciPrikaz() {
  switch ( symb ) {
    case IDENT:
      cout << "23 PrirazovaciPrikaz -> identifikator := Vyraz" << endl;
      compare( IDENT );
      compare( ASSIGN );
      Vyraz();
      break;
    default:
      synError( "At PrirazovaciPrikaz." );
  }
}

void Vyraz() {
  switch ( symb ) {
    case PLUS: case MINUS: case IDENT: case INT: case FLOAT: case LPAR:
      cout << "24 Vyraz -> Znamenko Term ZbytekVyrazu" << endl;
      Znamenko();
      Term();
      ZbytekVyrazu();
      break;
    default:
      synError( "At Vyraz." );
  }
}

void Znamenko() {
  switch ( symb ) {
    case PLUS:
      cout << "25 Znamenko -> +" << endl;
      compare( PLUS );
      break;
    case MINUS:
      cout << "26 Znamenko -> -" << endl;
      compare( MINUS );
      break;
    case IDENT: case INT: case FLOAT: case LPAR:
      cout << "27 Znamenko -> e" << endl;
      break;
    default:
      synError( "At Znamenko." );
  }
}

void Term() {
  switch ( symb ) {
    case IDENT: case INT: case FLOAT: case LPAR:
      cout << "28 Term -> Faktor ZbytekTermu" << endl;
      Faktor();
      ZbytekTermu();
      break;
    default:
      synError( "At Term." );
  }
}

void Faktor() {
  switch ( symb ) {
    case IDENT:
      cout << "29 Faktor -> identifikator" << endl;
      compare( IDENT );
      break;
    case INT:
      cout << "30 Faktor -> celeCislo" << endl;
      compare( INT ); 
      break;
    case FLOAT:
      cout << "31 Faktor -> realneCislo" << endl;
      compare( FLOAT );
      break;
    case LPAR:
      cout << "32 Faktor -> ( Vyraz )" << endl;
      compare( LPAR );
      Vyraz();
      compare( RPAR );
      break;
    default:
      synError( "At Faktor." );
  }
}

void ZbytekTermu() {
  switch ( symb ) {
    case ASTER: case SLASH: case kwDIV: case kwMOD:
      cout << "33 ZbytekTermu -> MultiplikativniOperator Faktor ZbytekTermu" << endl;
      MultiplikativniOperator();
      Faktor();
      ZbytekTermu();
      break;
    case PLUS: case MINUS: case EQ: case NEQ: case LESS: case GREAT: case LESSEQ: case GREATEQ: case SCOL: case RPAR: case kwDO: case kwIF:
    case kwTHEN: case kwELSE: case kwTO: case kwDOWNTO: case kwWRITELN: case kwFOR: case IDENT:
      cout << "34 ZbytekTermu -> e" << endl;
      break;
    default:
      synError( "At ZbytekTermu." );
  }
}

void MultiplikativniOperator() {
  switch ( symb ) {
    case ASTER:
      cout << "35 MultiplikativniOperator -> *" << endl;
      compare( ASTER );
      break;
    case SLASH:
      cout << "36 MultiplikativniOperator -> /" << endl;
      compare( SLASH );
      break;
    case kwDIV:
      cout << "37 MultiplikativniOperator -> div" << endl;
      compare( kwDIV );
      break;
    case kwMOD:
      cout << "38 MultiplikativniOperator -> mod" << endl;
      compare( kwMOD );
      break;
    default:
      synError( "At MultiplikativniOperator." );
  }
}

void ZbytekVyrazu() {
  switch ( symb ) {
    case PLUS: case MINUS:
      cout << "39 ZbytekVyrazu -> AditivniOperator Term ZbytekVyrazu" << endl;
      AditivniOperator();
      Term();
      ZbytekVyrazu();
      break;
    case RPAR: case SCOL: case kwDO: case kwELSE: case kwTHEN: case kwTO: case kwDOWNTO: case EQ: case NEQ: case LESS: case GREAT: case LESSEQ: case GREATEQ: 
      cout << "40 ZbytekVyrazu -> e" << endl;
      break;
    default:
      synError( "At ZbytekVyrazu." );
  }
}

void AditivniOperator() {
  switch ( symb ) {
    case PLUS:
      cout << "41 AditivniOperator -> +" << endl;
      compare( PLUS );
      break;
    case MINUS:
      cout << "42 AditivniOperator -> -" << endl;
      compare( MINUS );
      break;
    default:
      synError( "At AditivniOperator." );
  }
}

void ZbytekPosloupnostiPrikazu() {
  switch ( symb ) {
    case SCOL:
      cout << "43 ZbytekPosloupnostiPrikazu -> ; Prikaz ZbytekPosloupnostiPrikazu" << endl;
      compare( SCOL );
      Prikaz();
      ZbytekPosloupnostiPrikazu();
      break;
    case kwEND:
      cout << "44 ZbytekPosloupnostiPrikazu -> e" << endl;
      break;
    default:
      synError( "At ZbytekPosloupnostiPrikazu." );
  }
}

void PrikazIf() {
  switch ( symb ) {
    case kwIF:
      cout << "45 PrikazIf -> if Podminka then Prikaz CastElse" << endl;
      compare( kwIF );
      Podminka();
      compare( kwTHEN );
      Prikaz();
      CastElse();
      break;
    default:
      synError( "At PrikazIf." );
  }
}

void Podminka() {
  switch ( symb ) {
    case PLUS: case MINUS: case IDENT: case INT: case FLOAT: case LPAR:
      cout << "46 Podminka -> Vyraz RelacniOperator Vyraz" << endl;
      Vyraz();
      RelacniOperator();
      Vyraz();
      break;
    default:
      synError( "At Podminka." );
  }
}

void RelacniOperator() {
  switch ( symb ) {
    case EQ:
      cout << "47 RelacniOperator -> =" << endl;
      compare( EQ );
      break;
    case NEQ:
      cout << "48 RelacniOperator -> <>" << endl;
      compare( NEQ );
      break;
    case LESS:
      cout << "49 RelacniOperator -> <" << endl;
      compare( LESS );
      break;
    case GREAT:
      cout << "50 RelacniOperator -> >" << endl;
      compare( GREAT );
      break;
    case LESSEQ:
      cout << "51 RelacniOperator -> <=" << endl;
      compare( LESSEQ );
      break;
    case GREATEQ:
      cout << "52 RelacniOperator -> >=" << endl;
      compare( GREATEQ );
      break;
    default:
      synError( "At RelacniOperator." );
  }
}

void CastElse() {
  switch ( symb ) {
    case kwELSE:
      cout << "53 CastElse -> else Prikaz" << endl;
      compare( kwELSE );
      Prikaz();
      break;
    case SCOL:
      cout << "54 CastElse -> e" << endl;
      break;
    default:
      synError( "At CastElse." );
  }
}

void PrikazWhile() {
  switch ( symb ) {
    case kwWHILE:
      cout << "55 PrikazWhile -> while Podminka do Prikaz" << endl;
      compare( kwWHILE );
      Podminka();
      compare( kwDO );
      Prikaz();
      break;
    default:
      synError( "At PrikazWhile." );
  }
}

void PrikazFor() {
  switch ( symb ) {
    case kwFOR:
      cout << "56 PrikazFor -> for identifikator := Vyraz CastFor Vyraz do Prikaz" << endl;
      compare( kwFOR );
      compare( IDENT );
      compare( ASSIGN );
      Vyraz();
      CastFor();
      Vyraz();
      compare( kwDO );
      Prikaz();
      break;
    default:
      synError( "At PrikazFor." );
  }
}

void CastFor() {
  switch ( symb ) {
    case kwTO:
      cout << "57 CastFor -> to" << endl;
      compare( kwTO );
      break;
    case kwDOWNTO:
      cout << "58 CastFor -> downto" << endl;
      compare( kwDOWNTO );
      break;
    default:
      synError( "At CastFor." );
  }
}

void PrikazWriteln() {
  switch ( symb ) {
    case kwWRITELN:
      cout << "59 PrikazWriteln -> writeln ( Vyraz )" << endl;
      compare( kwWRITELN );
      compare( LPAR );
      Vyraz();
      compare( RPAR );
      break;
    default:
      synError( "At PrikazWriteln." );
  }
}
