#include <iostream>
#include <fstream>
using namespace std;

ofstream outFile;

int initializeOutput(char * filename ) {
  outFile.open( filename, ifstream::out );
  if ( outFile.is_open() ) {
    return( 0 );
  }
  else {
    return( -1 );
  }
}

int write( char * buffer ) {
  if ( outFile.good() ) {
    outFile << buffer << endl;
  }
  else {
    return( -1 );
  }
}

void closeOutput() {
  if ( outFile.is_open() ) {
    outFile.close();
  }
  return;
}
