#include <iostream>
#include <fstream>
using namespace std;

ifstream inFile;

int initializeInput(char * filename ) {
  inFile.open( filename, ifstream::in );
  if ( inFile.is_open() ) {
    return( 0 );
  }
  else {
    return( -1 );
  }
}

int readChar() {
  if ( inFile.eof() ) {
    return EOF;
  }
  if ( inFile.good() ) {
    return inFile.get();
  }
  else {
    return( -1 );
  }
}

void closeInput() {
  if ( inFile.is_open() ) {
    inFile.close();
  }
  return;
}
