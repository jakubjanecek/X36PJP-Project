#include "lexan.h"
#include "synan.h"
#include <iostream>
using namespace std;

int main( int argc, char * argv[] ) {
  if ( argc != 3 ) {
    cout << "USAGE: compiler [input] [output]" << endl;
	return( -1 );
  }
  initializeLexan( argv[1] );
  readSymb();
  initializeSynan( argv[2] );
  if ( symb != EOI ) {
    cout << "Unexpected symbol." << endl;
  }
  else {
    cout << endl << "INPUT ACCEPTED" << endl;
  }
  cleanUpSynan();
  cleanUp();
  return( 0 );
}
