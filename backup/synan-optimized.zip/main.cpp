#include "lexan.h"
#include "synan.h"
#include <iostream>
using namespace std;

int main( int argc, char * argv[] ) {
  if ( argc != 2 ) {
    cout << "USAGE: compiler [filename]" << endl;
	return( -1 );
  }
  initializeLexan( argv[1] );
  readSymb();
  Program();
  if ( symb != EOI ) {
    cout << "Unexpected symbol." << endl;
  }
  else {
    cout << endl << "INPUT ACCEPTED" << endl;
  }
  cleanUp();

  return( 0 );
}
