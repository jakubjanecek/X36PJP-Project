int get();
void use( int );
