#include "symboltable.h"
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

Item::Item( char * i, Type t, int a, Item * n ) {
  ident = new char[ strlen( i ) + 1 ];
  strcpy( ident, i );
  type = t;
  address = a;
  next = n;
}

static Item	* head;
static int availableAddress = 0;

void tabError( string msg ) {
  cout << endl << "SYMBOL TABLE ERROR: " << msg << endl << endl;
  exit( -1 );
}

void addVariable( char * i ) {
  Item * p = find( i );
  if ( p ) {
    tabError( "Identifier already used." );
  }
  head = new Item( i, NONE, 0, head );
}

Item * find( char * i ) {
  Item * p = head;
  while( p ) {
    if ( strcmp( i, p -> ident ) == 0 ) {
      return p;
    }
    else {
      p = p -> next;
    }
  }
  return NULL;
}

void changeType( Type t ) {
  Item * p = head;
  while( p ) {
    if ( p -> type == NONE ) {
      p -> type = t;
      p -> address = availableAddress;
      if ( t == REALNUM ) {
        availableAddress += 2;
      }
      else {
        availableAddress++;
      }
    }
    p = p -> next;
  }
}
