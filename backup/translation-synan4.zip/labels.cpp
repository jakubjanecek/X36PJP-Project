int counter = 0;

int get() {
  return counter;
}

void use( int number ) {
  counter += number;
}
