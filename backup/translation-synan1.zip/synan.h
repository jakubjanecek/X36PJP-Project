void initializeSynan( char * );
void cleanUpSynan();
