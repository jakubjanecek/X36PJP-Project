#include "lexan.h"
#include <iostream>
using namespace std;

int main( int argc, char * argv[] ) {
  if ( argc != 2 ) {
    cout << "USAGE: compiler [filename]" << endl;
	return( -1 );
  }
  initializeLexan( argv[1] );
  readSymb();
  while ( symb != EOI ) {
    switch ( symb ) {
      case IDENT:
        cout << "IDENT: " << ident << endl;
        break;
      case INT:
        cout << "INT: " << number << endl;
        break;
      case FLOAT:
        cout << "FLOAT: " << realNumber << endl;
        break;
      case kwPROGRAM:
        cout << "kwPROGRAM" << endl;
        break;
      case kwVAR:
        cout << "kwVAR" << endl;
        break;
      case kwINTEGER:
        cout << "kwINTEGER" << endl;
        break;
      case kwREAL:
        cout << "kwREAL" << endl;
        break;
      case kwBEGIN:
        cout << "kwBEGIN" << endl;
        break;
      case kwEND:
        cout << "kwEND" << endl;
        break;
      case kwDIV:
        cout << "kwDIV" << endl;
        break;
      case kwMOD:
        cout << "kwMOD" << endl;
        break;
      case kwAND:
        cout << "kwAND" << endl;
        break;
      case kwOR:
        cout << "kwOR" << endl;
        break;
      case kwIF:
        cout << "kwIF" << endl;
        break;
      case kwTHEN:
        cout << "kwTHEN" << endl;
        break;
      case kwELSE:
        cout << "kwELSE" << endl;
        break;
      case kwWHILE:
        cout << "kwWHILE" << endl;
        break;
      case kwDO:
        cout << "kwDO" << endl;
        break;
      case kwFOR:
        cout << "kwFOR" << endl;
        break;
      case kwTO:
        cout << "kwTO" << endl;
        break;
      case kwDOWNTO:
        cout << "kwDOWNTO" << endl;
        break;
      case kwWRITELN:
        cout << "kwWRITELN" << endl;
        break;
      case LPAR :
        cout << "LPAR" << endl;
        break;
      case RPAR :
        cout << "RPAR" << endl;
        break;
      case COM :
        cout << "COM" << endl;
        break;
      case COL :
        cout << "COL" << endl;
        break;
      case SCOL :
        cout << "SCOL" << endl;
        break;
      case ASSIGN :
        cout << "ASSIGN" << endl;
        break;
      case PLUS :
        cout << "PLUS" << endl;
        break;
      case MINUS :
        cout << "MINUS" << endl;
        break;
      case ASTER :
        cout << "ASTER" << endl;
        break;
      case SLASH :
        cout << "SLASH" << endl;
        break;
      case EQ :
        cout << "EQ" << endl;
        break;
      case NEQ :
        cout << "NEQ" << endl;
        break;
      case LESS :
        cout << "LESS" << endl;
        break;
      case GREAT :
        cout << "GREAT" << endl;
        break;
      case LESSEQ :
        cout << "LESSEQ" << endl;
        break;
      case GREATEQ :
        cout << "GREATEQ" << endl;
        break;
      case DOT :
        cout << "DOT" << endl;
        break;
      default:
        break;
    }
	readSymb();
  }
  cleanUp();

  system( "PAUSE" );
  return( 0 );
}
